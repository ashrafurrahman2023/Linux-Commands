

#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <vector>
#include <set>
#include <map>
#include <unordered_set>
#include <unordered_map>
#include <queue>
#include <ctime>
#include <cassert>
#include <complex>
#include <string>
#include <cstring>
#include "iomanip"
#include <chrono>
#include <random>
#include <bitset>
#include <array>
#include <climits>
#define ll long long
#define pb push_back
#define ld long double
using namespace std;
#include "stack"

ll mod = 1e9 + 7;
ld pi = 3.14159265359;
ld eps = 0.000000001;
ll Prime = 9011;
#include <iostream>
#include <vector>
#include <iostream>
#include <fstream>

#define ll long long
#define pb push_back

int main()
{
  int t;
  cin >> t;
  cout << t << endl;
}